package org.example

class Campanha(
    var nome: String,
) {


}