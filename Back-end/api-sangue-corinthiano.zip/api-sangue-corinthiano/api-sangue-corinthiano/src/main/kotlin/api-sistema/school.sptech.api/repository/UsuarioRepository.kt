//package ProjetoPI.ProjetoDoadores.repository
//
//import ProjetoPI.ProjetoDoadores.domain.Usuario
//import org.springframework.data.jpa.repository.JpaRepository
//
//interface UsuarioRepository:JpaRepository<Usuario, Int> {
//}