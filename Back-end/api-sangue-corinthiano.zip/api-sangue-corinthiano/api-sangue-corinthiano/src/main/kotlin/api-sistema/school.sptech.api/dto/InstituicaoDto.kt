package ProjetoPI.ProjetoDoadores.dto


data class InstituicaoDto(
    val nome: String,
    val latitude: Double,
    val longitude: Double
)