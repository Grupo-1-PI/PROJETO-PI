package ProjetoPI.ProjetoDoadores.domain

import jakarta.persistence.*

@Entity
class Instituicao(
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    var idInstituicao: Int? = null,

    var nome: String? = null,

    var cnpj: String? = null,

    var tipoInstituicao: String? = null,

    // Relacionamento OneToMany correto, referenciando "instituicao" na classe EnderecoInstituicao
    @OneToMany(mappedBy = "instituicao", cascade = [CascadeType.ALL])
    var enderecos: List<EnderecoInstituicao>? = null
)
