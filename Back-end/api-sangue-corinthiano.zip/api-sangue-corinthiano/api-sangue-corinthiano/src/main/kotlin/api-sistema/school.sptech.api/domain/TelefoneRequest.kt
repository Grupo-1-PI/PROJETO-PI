package ProjetoPI.ProjetoDoadores.domain

data class TelefoneRequest(
    val ddd: String,
    val telCel: String
)