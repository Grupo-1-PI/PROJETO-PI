//package ProjetoPI.ProjetoDoadores.domain
//
//import jakarta.persistence.*
//
//@Entity
//@Table(name = "vw_taxa_retencao")
//data class TaxaRetencao(
//    @field:Id
//    val id : Long = 1L,
//    @Column(name = "taxa_retencao")
//    val taxaRetencao: Double
//){
////    constructor() : this(0, 0, 0, 0)
//}
